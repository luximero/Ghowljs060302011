import { GoogleGenAI } from "@google/genai";

// Fix: Refactored to follow @google/genai guidelines:
// 1. Used process.env.API_KEY directly.
// 2. Used the correct initialization pattern.
// 3. Accessed the .text property of GenerateContentResponse correctly.
export async function getGeminiResponse(userPrompt: string): Promise<string> {
  try {
    // Always use the apiKey from process.env.API_KEY directly.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Using gemini-3-flash-preview for simple chat interaction.
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: "You are a helpful friend on Telegram. Keep your messages concise, informal, and friendly, as if chatting on a mobile app. Use emojis occasionally.",
        temperature: 0.8,
      },
    });
    
    // Accessing .text property directly as per instructions (not as a method).
    return response.text || "I didn't quite catch that.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Something went wrong with my brain. Try again later!";
  }
}