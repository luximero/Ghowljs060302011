export interface Message {
  id: string;
  senderId: string;
  text?: string;
  image?: string; // Base64 or URL
  isVoice?: boolean;
  voiceUrl?: string; // Real audio blob URL
  isSticker?: boolean;
  isCall?: boolean;
  voiceDuration?: number; // in seconds
  timestamp: Date;
  status: 'sending' | 'sent' | 'read';
  isSelf: boolean;
  replyToId?: string;
  isEdited?: boolean;
  forwardedFrom?: string; // Name of the original sender
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'offline' | 'typing...';
  lastSeen?: string;
}

export interface Chat {
  id: string;
  user: User;
  lastMessage?: string;
  lastMessageTime?: string;
  lastActivity: Date;
  unreadCount?: number;
  pinnedMessageId?: string;
}