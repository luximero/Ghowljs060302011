import { Chat, User } from './types';

export const THEMES = {
  dark: {
    bg: '#0e1621',
    sidebar: '#17212b',
    chatBg: '#0e1621',
    accent: '#2b5278',
    text: '#f5f5f5',
    secondaryText: '#708499',
    messageSelf: '#2b5278',
    messageOther: '#182533',
    activeChat: '#2b5278',
    border: '#0e1621',
    inputBg: '#17212b',
  },
  light: {
    bg: '#f4f4f5',
    sidebar: '#ffffff',
    chatBg: '#ffffff',
    accent: '#3390ec',
    text: '#000000',
    secondaryText: '#707579',
    messageSelf: '#eeffdb',
    messageOther: '#ffffff',
    activeChat: '#3390ec',
    border: '#dfe1e5',
    inputBg: '#ffffff',
  }
};

export const EMOJIS = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
  '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
  '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
  '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
  '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬'
];

export const STICKERS = [
  'https://cdn.pixabay.com/photo/2017/01/31/15/33/animal-2025114_1280.png',
  'https://cdn.pixabay.com/photo/2016/04/01/09/51/animal-1299616_1280.png',
  'https://cdn.pixabay.com/photo/2017/01/31/15/33/animal-2025113_1280.png',
  'https://cdn.pixabay.com/photo/2016/03/31/15/06/bear-1292985_1280.png',
  'https://cdn.pixabay.com/photo/2016/03/31/15/06/bear-1292983_1280.png',
  'https://cdn.pixabay.com/photo/2016/03/31/15/06/bear-1292982_1280.png',
  'https://cdn.pixabay.com/photo/2017/01/31/15/33/animal-2025110_1280.png',
  'https://cdn.pixabay.com/photo/2016/03/31/15/06/bear-1292984_1280.png',
];

export const TG_GRADIENTS = [
  'linear-gradient(135deg, #ff885e 0%, #ff516a 100%)',
  'linear-gradient(135deg, #ffcd00 0%, #ffa800 100%)',
  'linear-gradient(135deg, #64d2ff 0%, #5ac8fa 100%)',
  'linear-gradient(135deg, #4cd964 0%, #28cd41 100%)',
  'linear-gradient(135deg, #2196f3 0%, #007aff 100%)',
  'linear-gradient(135deg, #9c27b0 0%, #8e24aa 100%)',
  'linear-gradient(135deg, #ff4081 0%, #e91e63 100%)',
  'linear-gradient(135deg, #f44336 0%, #d32f2f 100%)',
];

export const MOCK_USERS: User[] = [
  { id: 'saved', name: 'Saved Messages', avatar: '', status: 'online' },
  { id: '1', name: 'Gemini AI', avatar: 'https://picsum.photos/seed/gemini/100', status: 'online' },
  { id: '2', name: 'Pavel Durov', avatar: '', status: 'offline', lastSeen: '2 hours ago' },
  { id: '3', name: 'Design Team', avatar: '', status: 'online' },
  { id: '4', name: 'Crypto Whale', avatar: 'https://picsum.photos/seed/crypto/100', status: 'online' },
  { id: '5', name: 'Mom', avatar: '', status: 'offline', lastSeen: 'yesterday' },
  { id: '6', name: 'Work Channel', avatar: 'https://picsum.photos/seed/work/100', status: 'online' },
];

export const INITIAL_CHATS: Chat[] = MOCK_USERS.map((user, index) => ({
  id: user.id,
  user: user,
  lastMessage: user.id === 'saved' ? "Store your items here" : "Hey! How is the new clone coming along?",
  lastMessageTime: "12:45 PM",
  lastActivity: new Date(Date.now() - index * 1000 * 60 * 60),
  unreadCount: user.id === 'saved' ? 0 : Math.floor(Math.random() * 3),
}));