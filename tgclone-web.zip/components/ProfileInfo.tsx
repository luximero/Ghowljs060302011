import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User } from '../types';
import { THEMES } from '../constants';
import { Language, translations } from '../translations';
import Avatar from './Avatar';

interface ProfileInfoProps {
  user: User;
  theme: 'dark' | 'light';
  language: Language;
  onClose: () => void;
}

const ProfileInfo: React.FC<ProfileInfoProps> = ({ user, theme, language, onClose }) => {
  const colors = THEMES[theme];
  const t = translations[language];
  const [activeTab, setActiveTab] = useState<'media' | 'files' | 'voice' | 'links'>('media');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const tabs = [
    { id: 'media', label: language === 'ru' ? 'Медиа' : 'Media' },
    { id: 'files', label: language === 'ru' ? 'Файлы' : 'Files' },
    { id: 'links', label: language === 'ru' ? 'Ссылки' : 'Links' },
    { id: 'voice', label: language === 'ru' ? 'Голос' : 'Voice' },
  ];

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="hidden md:flex flex-col w-[320px] lg:w-[400px] h-full border-l overflow-y-auto custom-scrollbar"
      style={{ backgroundColor: colors.sidebar, borderColor: colors.border }}
    >
      {/* Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between p-4 border-b bg-inherit" style={{ borderColor: colors.border }}>
        <h2 className="text-[17px] font-semibold" style={{ color: colors.text }}>
          {language === 'ru' ? 'Информация' : 'User Info'}
        </h2>
        <button onClick={onClose} className="p-2 rounded-full hover:bg-black/5 transition-colors" style={{ color: colors.secondaryText }}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2"/></svg>
        </button>
      </div>

      {/* Profile Section */}
      <div className="flex flex-col items-center p-6 gap-4">
        <Avatar user={user} size="xl" className="!w-40 !h-40 !text-5xl" />
        <div className="text-center">
          <h3 className="text-xl font-bold leading-tight" style={{ color: colors.text }}>{user.name}</h3>
          <span className={`text-sm ${user.status === 'online' ? 'text-[#27a7e7]' : ''}`} style={{ color: user.status === 'online' ? '#27a7e7' : colors.secondaryText }}>
            {user.status === 'online' ? t.online : `${t.lastSeen} ${user.lastSeen || 'recently'}`}
          </span>
        </div>
      </div>

      {/* Info Block */}
      <div className="px-6 py-4 space-y-6">
        <div className="flex items-center gap-6">
          <div className="text-[#27a7e7]"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2"/></svg></div>
          <div>
            <p className="text-[15px] font-medium" style={{ color: colors.text }}>{user.id === 'saved' ? 'Storage for your files' : 'Telegram User'}</p>
            <p className="text-xs" style={{ color: colors.secondaryText }}>{language === 'ru' ? 'О себе' : 'Bio'}</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-[#27a7e7]"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" strokeWidth="2"/></svg></div>
          <div>
            <p className="text-[15px] font-medium" style={{ color: colors.text }}>@{user.name.toLowerCase().replace(/\s+/g, '_')}</p>
            <p className="text-xs" style={{ color: colors.secondaryText }}>{language === 'ru' ? 'Имя пользователя' : 'Username'}</p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="text-[#27a7e7]"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" strokeWidth="2"/></svg></div>
            <p className="text-[15px] font-medium" style={{ color: colors.text }}>{language === 'ru' ? 'Уведомления' : 'Notifications'}</p>
          </div>
          <button 
            onClick={() => setNotificationsEnabled(!notificationsEnabled)}
            className={`w-10 h-5 rounded-full transition-colors relative ${notificationsEnabled ? 'bg-[#27a7e7]' : 'bg-[#708499]'}`}
          >
            <motion.div 
              animate={{ left: notificationsEnabled ? 24 : 4 }}
              className="absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm" 
            />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center border-b px-2 sticky top-[57px] bg-inherit z-10" style={{ borderColor: colors.border }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className="flex-1 py-3 text-[14px] font-medium transition-colors relative"
            style={{ color: activeTab === tab.id ? '#27a7e7' : colors.secondaryText }}
          >
            {tab.label}
            {activeTab === tab.id && (
              <motion.div layoutId="profile-tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#27a7e7]" />
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="p-1">
        {activeTab === 'media' && (
          <div className="grid grid-cols-3 gap-1">
            {[...Array(12)].map((_, i) => (
              <div 
                key={i} 
                className="aspect-square bg-black/5 hover:opacity-80 transition-opacity cursor-pointer overflow-hidden"
              >
                <img 
                  src={`https://picsum.photos/seed/${user.id}-${i}/200`} 
                  className="w-full h-full object-cover" 
                  alt="" 
                />
              </div>
            ))}
          </div>
        )}
        {activeTab !== 'media' && (
          <div className="flex flex-col items-center justify-center py-20 opacity-30 gap-3">
             <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9l-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" strokeWidth="1.5"/></svg>
             <p className="text-sm font-medium">{language === 'ru' ? 'Пусто' : 'Empty'}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default ProfileInfo;