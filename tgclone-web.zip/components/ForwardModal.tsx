
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Chat } from '../types';
import { THEMES } from '../constants';
import { Language, translations } from '../translations';
import Avatar from './Avatar';

interface ForwardModalProps {
  isOpen: boolean;
  onClose: () => void;
  chats: Chat[];
  onForward: (chatId: string) => void;
  theme: 'dark' | 'light';
  language: Language;
}

const ForwardModal: React.FC<ForwardModalProps> = ({ isOpen, onClose, chats, onForward, theme, language }) => {
  const colors = THEMES[theme];
  const t = translations[language];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="relative w-full max-w-[400px] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
          style={{ backgroundColor: colors.sidebar }}
        >
          <div className="p-4 border-b flex items-center justify-between" style={{ borderColor: colors.border }}>
            <h2 className="text-xl font-semibold" style={{ color: colors.text }}>{t.forwardTo}</h2>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-black/5 text-[#708499]">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2"/></svg>
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {chats.map(chat => (
              <div 
                key={chat.id} 
                onClick={() => onForward(chat.id)}
                className="flex items-center gap-4 px-4 py-3 hover:bg-black/5 cursor-pointer transition-colors"
              >
                <Avatar user={chat.user} size="md" />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate" style={{ color: colors.text }}>{chat.user.name === 'Saved Messages' ? t.savedMessages : chat.user.name}</h3>
                  <p className="text-sm opacity-60 truncate" style={{ color: colors.secondaryText }}>{chat.user.status === 'online' ? t.online : t.offline}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ForwardModal;
