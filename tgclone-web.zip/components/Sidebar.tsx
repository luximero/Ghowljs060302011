import React, { useState } from 'react';
import { Chat, User } from '../types';
import { THEMES } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import { Language, translations } from '../translations';
import Avatar from './Avatar';

interface SidebarProps {
  currentUser: User;
  onUpdateCurrentUser: (updates: Partial<User>) => void;
  chats: Chat[];
  activeChatId: string | null;
  onChatSelect: (chat: Chat) => void;
  isMobileChatOpen: boolean;
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  typingChatIds: Set<string>;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onOpenSavedMessages: () => void;
  onOpenSettings: () => void;
  language: Language;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  currentUser, chats, activeChatId, onChatSelect, isMobileChatOpen,
  searchQuery, setSearchQuery, typingChatIds, theme, onToggleTheme,
  onOpenSavedMessages, onOpenSettings, language
}) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const colors = THEMES[theme];
  const t = translations[language];

  return (
    <div className={`
      ${isMobileChatOpen ? 'hidden md:flex' : 'flex'}
      flex-col w-full md:w-[380px] h-full border-r relative select-none transition-colors duration-300
    `} style={{ backgroundColor: colors.sidebar, borderColor: colors.border }}>
      
      <AnimatePresence>
        {isDrawerOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsDrawerOpen(false)}
              className="fixed inset-0 bg-black/40 z-[100]"
            />
            <motion.div 
              initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-[280px] z-[101] shadow-2xl flex flex-col"
              style={{ backgroundColor: colors.sidebar }}
            >
              <div className="p-6 bg-[#2b5278] text-white flex flex-col gap-4">
                <Avatar user={currentUser} size="xl" borderColor="#2b5278" showBadge />
                <div><h3 className="font-semibold text-lg">{currentUser.name}</h3><p className="text-white/70 text-sm">+7 (999) 123-45-67</p></div>
              </div>
              <div className="flex-1 py-2 overflow-y-auto">
                <MenuButton icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>} label={t.newGroup} colors={colors} />
                <MenuButton icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 00-7 7h14a7 7 0 00-7-7z" /></svg>} label={t.contacts} colors={colors} />
                <MenuButton icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>} label={t.calls} colors={colors} />
                <MenuButton icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>} label={t.savedMessages} onClick={() => { onOpenSavedMessages(); setIsDrawerOpen(false); }} colors={colors} />
                <MenuButton icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>} label={t.settings} onClick={() => { onOpenSettings(); setIsDrawerOpen(false); }} colors={colors} />
                <div className="px-4 py-3 flex items-center justify-between hover:bg-black/5 cursor-pointer transition-colors" onClick={onToggleTheme}>
                  <div className="flex items-center gap-6"><span className="text-[#708499]"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg></span><span className="font-medium" style={{ color: colors.text }}>{t.nightMode}</span></div>
                  <div className={`w-10 h-5 rounded-full transition-colors relative ${theme === 'dark' ? 'bg-[#27a7e7]' : 'bg-[#708499]'}`}><div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${theme === 'dark' ? 'left-6' : 'left-1'}`} /></div>
                </div>
              </div>
              <div className="p-4 text-xs text-[#708499] border-t" style={{ borderColor: colors.border }}>{t.version}</div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="p-4 flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <button onClick={() => setIsDrawerOpen(true)} className="ripple p-2 text-[#708499] hover:text-[#40a7e3] transition-colors rounded-full"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg></button>
          <div className="flex-1 rounded-full px-4 py-2 flex items-center gap-3 border transition-all" style={{ backgroundColor: theme === 'dark' ? '#242f3d' : '#f1f1f1', borderColor: 'transparent' }}>
            <svg className="w-5 h-5 text-[#708499]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={t.search} className="bg-transparent border-none outline-none text-sm w-full placeholder-[#708499]" style={{ color: colors.text }} />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar px-1">
        <AnimatePresence initial={false}>
          {chats.map((chat) => {
            const isTyping = typingChatIds.has(chat.id);
            const isActive = activeChatId === chat.id;
            return (
              <motion.div 
                layout
                key={chat.id} 
                onClick={() => onChatSelect(chat)} 
                className={`flex items-center gap-3 px-4 py-3 cursor-pointer rounded-xl transition-colors mb-0.5 ${isActive ? (theme === 'dark' ? 'bg-[#2b5278]' : 'bg-[#27a7e7] text-white shadow-lg') : 'hover:bg-black/5'}`}
              >
                <Avatar user={chat.user} size="lg" showBadge borderColor={isActive ? (theme === 'dark' ? '#2b5278' : '#27a7e7') : colors.sidebar} />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline"><h3 className={`font-semibold text-[16px] truncate`} style={{ color: isActive ? 'white' : colors.text }}>{chat.user.name === 'Saved Messages' ? t.savedMessages : chat.user.name}</h3><span className={`text-[12px] ${isActive ? 'text-white/80' : 'text-[#708499]'}`}>{chat.lastMessageTime}</span></div>
                  <div className="flex justify-between items-center mt-1"><p className={`text-[14px] truncate flex-1 ${isTyping ? (isActive ? 'text-white' : 'text-[#40a7e3]') : isActive ? 'text-white/90' : 'text-[#708499]'}`}>{isTyping ? t.typing : chat.lastMessage}</p>
                    {chat.unreadCount ? chat.unreadCount > 0 && <span className={`ml-2 text-[12px] font-bold px-2 py-0.5 rounded-full min-w-[22px] h-[22px] flex items-center justify-center`} style={{ backgroundColor: isActive ? 'white' : '#27a7e7', color: isActive ? (theme === 'dark' ? '#2b5278' : '#27a7e7') : 'white' }}>{chat.unreadCount}</span> : null}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};

const MenuButton: React.FC<{ icon: React.ReactNode, label: string, onClick?: () => void, colors: any }> = ({ icon, label, onClick, colors }) => (
  <button onClick={onClick} className="ripple w-full flex items-center gap-6 px-4 py-3 hover:bg-black/5 transition-colors">
    <span className="text-[#708499]">{icon}</span>
    <span className="font-medium" style={{ color: colors.text }}>{label}</span>
  </button>
);

export default Sidebar;