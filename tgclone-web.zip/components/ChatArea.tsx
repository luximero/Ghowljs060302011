import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Chat, Message } from '../types';
import { THEMES } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import { Language, translations } from '../translations';
import Avatar from './Avatar';
import EmojiPicker from './EmojiPicker';

interface ChatAreaProps {
  chat: Chat | null;
  messages: Message[];
  onSendMessage: (text?: string, replyToId?: string, editId?: string, image?: string, isVoice?: boolean, voiceDuration?: number, forwardedFrom?: string, isSticker?: boolean, isCall?: boolean, voiceUrl?: string, mediaData?: string) => void;
  onDeleteMessage: (id: string) => void;
  onPinMessage: (id: string) => void;
  onUnpinMessage: () => void;
  onBack: () => void;
  onHeaderClick?: () => void;
  isTyping?: boolean;
  theme: 'dark' | 'light';
  language: Language;
  selectedMessageIds: string[];
  onSelectMessage: (id: string) => void;
  onClearSelection: () => void;
  onDeleteSelected: () => void;
  onForwardSelected: () => void;
  onStartSelection: (id: string) => void;
}

const formatDateDivider = (date: Date, language: Language) => {
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) return language === 'ru' ? 'Сегодня' : 'Today';
  if (date.toDateString() === yesterday.toDateString()) return language === 'ru' ? 'Вчера' : 'Yesterday';
  return date.toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US', { month: 'long', day: 'numeric', year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined });
};

const FormattedText: React.FC<{ text: string, theme: 'dark' | 'light', searchQuery?: string, isActiveMatch?: boolean }> = ({ text, theme, searchQuery, isActiveMatch }) => {
  const parts = text.split(/(\*\*.*?\*\*|__.*?__|https?:\/\/[^\s]+)/g);
  
  const renderHighlighted = (segment: string) => {
    if (!searchQuery || searchQuery.length < 1) return <span>{segment}</span>;
    const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const highlightedParts = segment.split(regex);
    return (
      <>
        {highlightedParts.map((part, i) => 
          regex.test(part) ? (
            <mark key={i} className={`search-highlight ${isActiveMatch ? 'search-highlight-active' : ''}`}>
              {part}
            </mark>
          ) : (
            <span key={i}>{part}</span>
          )
        )}
      </>
    );
  };

  return (
    <>
      {parts.map((part, i) => {
        if (part.startsWith('http')) return <a key={i} href={part} target="_blank" rel="noopener noreferrer" className="text-[#27a7e7] hover:underline break-all">{part}</a>;
        if (part.startsWith('**') && part.endsWith('**')) return <strong key={i} className="font-bold">{part.slice(2, -2)}</strong>;
        if (part.startsWith('__') && part.endsWith('__')) return <em key={i} className="italic">{part.slice(2, -2)}</em>;
        return <React.Fragment key={i}>{renderHighlighted(part)}</React.Fragment>;
      })}
    </>
  );
};

const VoiceMessageContent: React.FC<{ voiceUrl?: string, duration: number, isSelf: boolean, colors: any }> = ({ voiceUrl, duration, isSelf, colors }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [actualDuration, setActualDuration] = useState(duration || 0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = new Audio();
    audio.preload = "metadata";
    audioRef.current = audio;
    
    const handleLoadedMetadata = () => {
      if (audio.duration && isFinite(audio.duration) && audio.duration > 0) {
        setActualDuration(audio.duration);
      }
    };
    
    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleEnded = () => { setIsPlaying(false); setCurrentTime(0); };
    const handleError = (e: any) => {
      // Don't log if there is no src or it's clearly missing
      if (audio.src && audio.src !== window.location.href) {
         console.warn("Audio playback error detected. The message source might be invalid.");
      }
      setIsPlaying(false);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);
    
    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
      audio.pause();
      audio.removeAttribute('src');
      audio.load();
      audioRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (audioRef.current && voiceUrl) {
      try {
        const src = voiceUrl.startsWith('data:') || voiceUrl.startsWith('blob:') 
          ? voiceUrl 
          : new URL(voiceUrl, window.location.href).href;
          
        if (audioRef.current.src !== src) {
          audioRef.current.src = src;
          audioRef.current.load();
        }
      } catch (err) {
        console.error("Failed to parse voiceUrl", err);
      }
    }
  }, [voiceUrl]);

  const togglePlay = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const audio = audioRef.current;
    if (!audio || !audio.src || audio.src === window.location.href) return;
    
    try {
      if (isPlaying) {
        audio.pause();
        setIsPlaying(false);
      } else {
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          await playPromise;
          setIsPlaying(true);
        }
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn("Playback interrupted:", err.message);
      }
      setIsPlaying(false);
    }
  };

  const formatTime = (seconds: number) => {
    if (!isFinite(seconds) || isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = isFinite(actualDuration) && actualDuration > 0 ? (currentTime / actualDuration) * 100 : 0;

  return (
    <div className="flex items-center gap-3 py-1 pr-1 w-full min-w-[200px]">
      <button onClick={togglePlay} className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors shrink-0 ${isSelf ? 'bg-black/10 hover:bg-black/20' : 'bg-[#27a7e7] text-white'}`}>
        {isPlaying ? <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg> : <svg className="w-5 h-5 ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>}
      </button>
      <div className="flex flex-col gap-1 flex-1">
        <div className="relative h-6 flex items-center">
          <div className={`absolute inset-0 h-1 my-auto rounded-full ${isSelf ? 'bg-black/10' : 'bg-[#27a7e7]/20'}`} />
          <div className={`absolute left-0 h-1 my-auto rounded-full bg-[#27a7e7] transition-all duration-100`} style={{ width: `${progress}%` }} />
          <div className="flex items-center gap-0.5 w-full h-full opacity-30 pointer-events-none">
            {[...Array(24)].map((_, i) => <div key={i} className={`w-[2px] rounded-full ${isSelf ? 'bg-black' : 'bg-[#27a7e7]'}`} style={{ height: `${Math.random() * 60 + 20}%` }} />)}
          </div>
        </div>
        <div className="flex justify-between w-full">
           <span className="text-[11px] opacity-60 font-medium">{formatTime(isPlaying ? currentTime : actualDuration)}</span>
        </div>
      </div>
    </div>
  );
};

const ChatArea: React.FC<ChatAreaProps> = ({ 
  chat, messages, onSendMessage, onDeleteMessage, onPinMessage, onUnpinMessage, onBack, onHeaderClick, isTyping, theme, language,
  selectedMessageIds, onSelectMessage, onClearSelection, onDeleteSelected, onForwardSelected, onStartSelection
}) => {
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [editingMsg, setEditingMsg] = useState<Message | null>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, msg: Message } | null>(null);
  const [isEmojiPickerOpen, setIsEmojiPickerOpen] = useState(false);
  
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingStartTimeRef = useRef<number>(0);
  const recordingIntervalRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messageRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentMatchIdx, setCurrentMatchIdx] = useState(0);

  const [isCallOverlayOpen, setIsCallOverlayOpen] = useState(false);
  const [callStatus, setCallStatus] = useState<'calling' | 'ringing'>('calling');
  const [callToggles, setCallToggles] = useState({ mute: false, video: false, speaker: false });
  
  const colors = THEMES[theme];
  const t = translations[language];
  const isSelectMode = selectedMessageIds.length > 0;

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(textareaRef.current.scrollHeight, 150);
      textareaRef.current.style.height = `${newHeight}px`;
    }
  }, [inputText]);

  useEffect(() => { 
    if (scrollRef.current && !isSearchOpen) scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); 
  }, [messages, isTyping, inputText, isEmojiPickerOpen, isSearchOpen]);

  useEffect(() => { 
    const h = () => setContextMenu(null); 
    window.addEventListener('click', h); 
    return () => window.removeEventListener('click', h); 
  }, []);

  const groupedMessages = messages.reduce((g: { date: string, msgs: Message[] }[], msg) => {
    const d = formatDateDivider(msg.timestamp, language);
    if (g[g.length - 1]?.date === d) g[g.length - 1].msgs.push(msg); else g.push({ date: d, msgs: [msg] });
    return g;
  }, []);

  const handleSend = () => {
    const trimmed = inputText.trim();
    if (trimmed || editingMsg) { 
      onSendMessage(trimmed, replyingTo?.id, editingMsg?.id); 
      setInputText(''); setReplyingTo(null); setEditingMsg(null); 
    }
  };

  const handleStickerSend = (url: string) => {
    onSendMessage(undefined, undefined, undefined, url, false, undefined, undefined, true);
    setIsEmojiPickerOpen(false);
  };

  const handleEmojiSelect = (emoji: string) => {
    const start = textareaRef.current?.selectionStart || 0;
    const end = textareaRef.current?.selectionEnd || 0;
    const text = inputText.substring(0, start) + emoji + inputText.substring(end);
    setInputText(text);
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const cursor = start + emoji.length;
        textareaRef.current.setSelectionRange(cursor, cursor);
      }
    }, 0);
  };

  const handleRecordingStart = async (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (isRecording) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const supportedTypes = [
        'audio/webm;codecs=opus',
        'audio/mp4',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/aac',
        'audio/wav'
      ];
      const mimeType = supportedTypes.find(type => MediaRecorder.isTypeSupported(type)) || '';
      
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      
      recorder.ondataavailable = (event) => { 
        if (event.data.size > 0) audioChunksRef.current.push(event.data); 
      };
      
      recorder.onstop = () => {
        const finalDuration = Math.round((performance.now() - recordingStartTimeRef.current) / 1000);
        
        if (audioChunksRef.current.length > 0) {
            const audioBlob = new Blob(audioChunksRef.current, { type: recorder.mimeType });
            const audioUrl = URL.createObjectURL(audioBlob);
            
            const reader = new FileReader();
            reader.readAsDataURL(audioBlob);
            reader.onloadend = () => {
              const base64data = reader.result as string;
              onSendMessage(undefined, replyingTo?.id, undefined, undefined, true, Math.max(1, finalDuration), undefined, false, false, audioUrl, base64data); 
              setReplyingTo(null); 
            };
        }
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start(100);
      setIsRecording(true);
      setRecordingTime(0);
      recordingStartTimeRef.current = performance.now();
      
      recordingIntervalRef.current = window.setInterval(() => {
        const elapsed = Math.round((performance.now() - recordingStartTimeRef.current) / 1000);
        setRecordingTime(elapsed);
      }, 500);
    } catch (err) { 
      console.error("Microphone access error:", err); 
    }
  };

  const handleRecordingEnd = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (!isRecording) return;
    
    setIsRecording(false);
    if (recordingIntervalRef.current) { 
      clearInterval(recordingIntervalRef.current); 
      recordingIntervalRef.current = null; 
    }
    
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const matches = useMemo(() => {
    if (!searchQuery || searchQuery.length < 1) return [];
    const q = searchQuery.toLowerCase();
    return messages.filter(m => m.text && m.text.toLowerCase().includes(q));
  }, [messages, searchQuery]);

  const scrollToMessage = (msgId: string) => {
    const el = messageRefs.current[msgId];
    if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('flash-highlight'); setTimeout(() => el.classList.remove('flash-highlight'), 1500); }
  };

  if (!chat) return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hidden md:flex flex-1 items-center justify-center" style={{ backgroundColor: colors.bg }}>
      <div className="px-6 py-2 rounded-full text-sm shadow-xl border" style={{ backgroundColor: colors.sidebar, color: colors.secondaryText, borderColor: colors.border }}>
        {language === 'ru' ? 'Выберите чат для начала общения' : 'Select a chat to start messaging'}
      </div>
    </motion.div>
  );

  const pinnedMsg = chat.pinnedMessageId ? messages.find(m => m.id === chat.pinnedMessageId) : null;

  return (
    <motion.div 
      key={chat.id}
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.2 }}
      className="flex flex-1 flex-col h-full relative overflow-hidden transition-colors duration-300" 
      style={{ backgroundColor: colors.bg }}
    >
      {/* Header */}
      <div className="z-20 h-[64px] border-b flex items-center px-4 gap-4 shadow-sm overflow-hidden" style={{ backgroundColor: colors.sidebar + 'f2', borderColor: colors.border }}>
        <AnimatePresence mode="wait">
          {isSearchOpen ? (
            <motion.div key="search" initial={{ y: -64 }} animate={{ y: 0 }} exit={{ y: -64 }} className="flex-1 flex items-center gap-2 h-full">
              <button onClick={() => setIsSearchOpen(false)} className="p-2 rounded-full hover:bg-black/5 text-[#708499]"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2.5"/></svg></button>
              <input autoFocus type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={t.searchInChat} className="flex-1 bg-transparent border-none outline-none text-[16px]" style={{ color: colors.text }} />
              {matches.length > 0 && <span className="text-xs font-medium text-[#708499] whitespace-nowrap">{currentMatchIdx + 1} {t.of} {matches.length}</span>}
              <button onClick={() => setCurrentMatchIdx(p => (p - 1 + matches.length) % matches.length)} disabled={matches.length === 0} className="p-2 text-[#708499] disabled:opacity-30"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 15l7-7 7 7" strokeWidth="2.5"/></svg></button>
              <button onClick={() => setCurrentMatchIdx(p => (p + 1) % matches.length)} disabled={matches.length === 0} className="p-2 text-[#708499] disabled:opacity-30"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" strokeWidth="2.5"/></svg></button>
            </motion.div>
          ) : isSelectMode ? (
            <motion.div key="select" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button onClick={onClearSelection} className="p-2 rounded-full hover:bg-black/5 text-[#708499]"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2.5"/></svg></button>
                <span className="font-semibold text-lg" style={{ color: colors.text }}>{selectedMessageIds.length} {t.selected}</span>
              </div>
            </motion.div>
          ) : (
            <motion.div key="header" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex items-center gap-4 overflow-hidden">
              <button onClick={onBack} className="ripple md:hidden p-2 -ml-2 rounded-full" style={{ color: colors.secondaryText }}><svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" strokeWidth="2.5" /></svg></button>
              <div className="flex flex-1 items-center gap-4 cursor-pointer min-w-0" onClick={onHeaderClick}>
                <Avatar user={chat.user} size="md" showBadge borderColor={colors.sidebar} />
                <div className="flex-1 min-w-0">
                  <h2 className="font-semibold text-[17px] truncate leading-tight" style={{ color: colors.text }}>{chat.user.name === 'Saved Messages' ? t.savedMessages : chat.user.name}</h2>
                  <span className={`text-[13px] ${isTyping || chat.user.status === 'online' ? 'text-[#27a7e7]' : ''}`} style={{ color: (isTyping || chat.user.status === 'online') ? '#27a7e7' : colors.secondaryText }}>{isTyping ? t.typing : (chat.user.status === 'online' ? t.online : `${t.lastSeen} ${chat.user.lastSeen || 'recently'}`)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setIsSearchOpen(true)} className="p-2.5 rounded-full hover:bg-black/5 text-[#708499] transition-colors"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeWidth="2"/></svg></button>
                <button onClick={() => setIsCallOverlayOpen(true)} className="p-2.5 rounded-full hover:bg-black/5 text-[#708499] transition-colors"><svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6.62,10.79C8.06,13.62 10.38,15.94 13.21,17.38L15.41,15.18C15.69,14.9 16.08,14.82 16.43,14.93C17.55,15.3 18.75,15.5 20,15.5A1,1 0 0,1 21,16.5V20A1,1 0 0,1 20,21A17,17 0 0,1 3,4A1,1 0 0,1 4,3H7.5A1,1 0 0,1 8.5,4C8.5,5.25 8.7,6.45 9.07,7.57C9.18,7.92 9.1,8.31 8.82,8.59L6.62,10.79Z" /></svg></button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {pinnedMsg && !isSelectMode && !isSearchOpen && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 48, opacity: 1 }} exit={{ height: 0, opacity: 0 }} onClick={() => scrollToMessage(pinnedMsg.id)} className="z-[15] border-b flex items-center px-4 gap-3 cursor-pointer select-none hover:bg-black/5" style={{ backgroundColor: colors.sidebar, borderColor: colors.border }}>
            <div className="w-0.5 h-8 bg-[#27a7e7] rounded-full" />
            <div className="flex-1 min-w-0 overflow-hidden">
              <span className="block text-[13px] font-semibold text-[#27a7e7]">{t.pinnedMessage}</span>
              <p className="text-[13px] opacity-70 truncate" style={{ color: colors.text }}>{pinnedMsg.isSticker ? 'Sticker' : pinnedMsg.text || 'Photo'}</p>
            </div>
            <button onClick={(e) => { e.stopPropagation(); onUnpinMessage(); }} className="p-1 text-[#708499] hover:bg-black/10 rounded-full"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2" /></svg></button>
          </motion.div>
        )}
      </AnimatePresence>

      <div ref={scrollRef} className="z-10 flex-1 overflow-y-auto px-4 py-4 space-y-3 flex flex-col scroll-smooth custom-scrollbar">
        {groupedMessages.map((group) => (
          <React.Fragment key={group.date}>
            <div className="flex justify-center sticky top-2 z-10 my-4">
              <span className="backdrop-blur-md text-[12px] font-medium px-3 py-1 rounded-full shadow-sm" style={{ backgroundColor: colors.sidebar + 'cc', color: theme === 'dark' ? 'white' : '#707579' }}>{group.date}</span>
            </div>
            
            <AnimatePresence initial={false}>
              {group.msgs.map((msg, index) => {
                const isSelected = selectedMessageIds.includes(msg.id);
                const isActiveMatch = isSearchOpen && matches.length > 0 && matches[currentMatchIdx]?.id === msg.id;

                return (
                  <motion.div 
                    layout
                    key={msg.id} 
                    initial={{ opacity: 0, y: 20, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.5, height: 0 }}
                    transition={{ type: 'spring', damping: 25, stiffness: 300, layout: { duration: 0.2 } }}
                    ref={el => messageRefs.current[msg.id] = el}
                    onContextMenu={(e) => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY, msg }); }}
                    onClick={() => isSelectMode && onSelectMessage(msg.id)}
                    className={`flex items-center w-full gap-2 px-2 py-0.5 transition-all rounded-lg ${isSelected ? 'bg-[#27a7e71a]' : 'hover:bg-black/5 cursor-pointer'}`}
                  >
                    <div className={`flex-1 flex ${msg.isSelf ? 'justify-end' : 'justify-start'} items-end gap-2`}>
                      {!msg.isSelf && (index === 0 || (group.msgs[index - 1] && group.msgs[index - 1].isSelf)) && <Avatar user={chat.user} size="sm" className="mb-0.5" />}
                      {!msg.isSelf && !(index === 0 || (group.msgs[index - 1] && group.msgs[index - 1].isSelf)) && <div className="w-8" />}
                      
                      <div 
                        style={{ backgroundColor: msg.isCall ? '#27a7e71a' : (msg.isSticker ? 'transparent' : (msg.isSelf ? colors.messageSelf : colors.messageOther)), color: msg.isSelf && theme === 'dark' ? 'white' : colors.text }} 
                        className={`max-w-[85%] md:max-w-[70%] relative ${msg.isSticker ? '' : 'shadow-sm shadow-black/10'} ${msg.isSelf ? 'rounded-2xl rounded-br-sm' : 'rounded-2xl rounded-bl-sm'} ${msg.image && !msg.isSticker ? 'p-1' : (msg.isSticker || msg.isCall ? '' : 'px-3 py-1.5')} ${msg.isCall ? 'border border-[#27a7e744] flex items-center gap-3 px-4 py-2' : ''} ${isActiveMatch ? 'ring-2 ring-[#27a7e7]' : ''}`}
                      >
                        {msg.isCall && <div className="w-8 h-8 rounded-full bg-[#27a7e7] flex items-center justify-center text-white shrink-0"><svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M21,12L14,5V9C7,10 4,15 3,20C5.5,16.5 9,15 14,15V19L21,12Z" /></svg></div>}
                        <div className="flex-1 min-w-0">
                          {msg.forwardedFrom && <div className="mb-1 text-[12px] text-[#27a7e7] font-semibold opacity-90 border-l-2 border-current pl-2">{t.forwardedFrom}: {msg.forwardedFrom}</div>}
                          {msg.replyToId && !msg.forwardedFrom && <div className="mb-1 pl-2 border-l-2 border-[#27a7e7] bg-black/5 rounded-r-md py-1 px-2 text-[13px] opacity-80 line-clamp-1">{messages.find(m => m.id === msg.replyToId)?.text}</div>}
                          {msg.image && <div className={`${msg.isSticker ? 'w-32 h-32 md:w-48 md:h-48' : 'rounded-xl overflow-hidden mb-1'}`}><img src={msg.image} className="w-full h-full object-contain" alt="" /></div>}
                          {msg.isVoice && <VoiceMessageContent voiceUrl={msg.voiceUrl} duration={msg.voiceDuration || 0} isSelf={msg.isSelf} colors={colors} />}
                          {msg.text && <p className={`text-[15px] whitespace-pre-wrap leading-relaxed ${msg.isCall ? 'font-medium' : ''}`}><FormattedText text={msg.text} theme={theme} searchQuery={isSearchOpen ? searchQuery : undefined} isActiveMatch={isActiveMatch} /></p>}
                        </div>
                        <div className={`flex items-center justify-end gap-1 mt-0.5 ml-3 float-right translate-y-0.5 ${msg.isSticker ? 'bg-black/20 px-1 rounded-full text-white' : ''}`}>
                          {msg.isEdited && <span className="text-[10px] opacity-40 italic mr-1">{t.edit}</span>}
                          <span className="text-[10px] opacity-50 font-medium">{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          {msg.isSelf && <span className="ml-0.5">{msg.status === 'read' ? <svg className="w-3.5 h-3.5 text-[#27a7e7]" fill="currentColor" viewBox="0 0 24 24"><path d="M0.41,13.41L6,19L7.41,17.58L1.83,12M22.24,5.58L11.66,16.17L7.5,12L6.07,13.41L11.66,19L23.66,7M18,7L16.59,5.58L10.24,11.93L11.66,13.34L18,7Z"/></svg> : <svg className="w-3.5 h-3.5 opacity-60" fill="currentColor" viewBox="0 0 24 24"><path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>}</span>}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </React.Fragment>
        ))}
      </div>

      {/* Input Area */}
      <AnimatePresence>
        {isSelectMode ? (
          <motion.div initial={{ y: 50 }} animate={{ y: 0 }} exit={{ y: 50 }} className="z-30 p-4 border-t flex justify-center gap-8 shadow-2xl" style={{ backgroundColor: colors.sidebar, borderColor: colors.border }}>
            <button onClick={onForwardSelected} className="flex flex-col items-center gap-1 text-[#27a7e7] hover:opacity-80"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14 5l7 7m0 0l-7 7m7-7H3" strokeWidth="2"/></svg><span className="text-xs font-semibold uppercase">{t.forward}</span></button>
            <button onClick={onDeleteSelected} className="flex flex-col items-center gap-1 text-red-500 hover:opacity-80"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2"/></svg><span className="text-xs font-semibold uppercase">{t.delete}</span></button>
          </motion.div>
        ) : (
          <div className="z-20 flex flex-col" style={{ backgroundColor: colors.bg }}>
            <AnimatePresence>
              {(replyingTo || editingMsg) && !isRecording && (
                <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="z-20 px-4 py-2 border-t flex items-center gap-3 overflow-hidden" style={{ backgroundColor: colors.sidebar, borderColor: colors.border }}>
                  <div className="text-[#27a7e7]">{replyingTo ? <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" /></svg> : <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>}</div>
                  <div className="flex-1 min-w-0 border-l-2 border-[#27a7e7] pl-3"><span className="block text-[13px] font-semibold text-[#27a7e7]">{replyingTo ? t.replyTo : t.editMessage}</span><p className="text-[13px] opacity-70 truncate">{replyingTo?.text || editingMsg?.text}</p></div>
                  <button onClick={() => { setReplyingTo(null); setEditingMsg(null); setInputText(''); }} className="p-1 text-[#708499] hover:text-red-500"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" /></svg></button>
                </motion.div>
              )}
            </AnimatePresence>
            
            <div className="p-2 md:p-4">
              <div className="max-w-[800px] w-full mx-auto flex items-end gap-3 relative">
                
                <div className={`flex-1 rounded-2xl p-2 flex items-end gap-1 shadow-sm border transition-all relative overflow-hidden`} style={{ backgroundColor: colors.inputBg, borderColor: colors.border }}>
                  <AnimatePresence>
                    {isRecording && (
                      <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-inherit flex items-center px-4 gap-4 z-10"
                      >
                        <motion.div animate={{ opacity: [1, 0, 1] }} transition={{ repeat: Infinity, duration: 1 }} className="w-3 h-3 rounded-full bg-red-500" />
                        <span className="font-mono text-[16px] font-semibold" style={{ color: colors.text }}>
                          {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}
                        </span>
                        <div className="flex-1 h-1 bg-black/5 rounded-full overflow-hidden">
                          <motion.div className="h-full bg-[#27a7e7]" initial={{ width: 0 }} animate={{ width: '100%' }} transition={{ duration: 60, ease: 'linear' }} />
                        </div>
                        <span className="text-[13px] text-[#708499] font-medium animate-pulse">{language === 'ru' ? 'Запись...' : 'Recording...'}</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button onClick={() => setIsEmojiPickerOpen(!isEmojiPickerOpen)} className={`p-2.5 transition-colors ${isEmojiPickerOpen ? 'text-[#27a7e7]' : 'text-[#708499] hover:text-[#27a7e7]'}`}><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2"/></svg></button>
                  <textarea ref={textareaRef} value={inputText} onChange={(e) => setInputText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }} placeholder={t.message} rows={1} className="flex-1 bg-transparent border-none outline-none text-[16px] py-2 resize-none max-h-48 custom-scrollbar" style={{ color: colors.text }} />
                  <button className="p-2.5 text-[#708499] hover:text-[#27a7e7] transition-colors"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" strokeWidth="2"/></svg></button>
                </div>
                
                <motion.button 
                  whileTap={{ scale: 1.1 }} 
                  onMouseDown={(e) => !inputText && handleRecordingStart(e)} 
                  onMouseUp={(e) => !inputText && handleRecordingEnd(e)} 
                  onTouchStart={(e) => !inputText && handleRecordingStart(e)} 
                  onTouchEnd={(e) => !inputText && handleRecordingEnd(e)} 
                  onClick={() => inputText && handleSend()} 
                  className={`w-12 h-12 flex items-center justify-center rounded-full transition-all shadow-md shrink-0 z-20 ${isRecording ? 'bg-red-500 scale-125' : (inputText ? 'bg-[#27a7e7]' : 'text-[#708499] hover:text-[#27a7e7]')}`}
                >
                  {inputText ? (
                    <svg className="w-6 h-6 text-white translate-x-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" /></svg>
                  ) : (
                    <svg className="w-6 h-6" fill={isRecording ? 'white' : 'none'} stroke="currentColor" viewBox="0 0 24 24"><path d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" strokeWidth="2" /></svg>
                  )}
                </motion.button>
              </div>
            </div>

            <AnimatePresence>{isEmojiPickerOpen && <EmojiPicker theme={theme} language={language} onEmojiSelect={handleEmojiSelect} onStickerSelect={handleStickerSend} />}</AnimatePresence>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isCallOverlayOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[9999] flex flex-col items-center justify-between py-20 bg-[#0e1621]">
            <div className="absolute inset-0 z-[-1] opacity-20"><img src={chat.user.avatar || ''} className="w-full h-full object-cover blur-[80px]" alt="" /></div>
            <div className="flex flex-col items-center gap-6">
              <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ repeat: Infinity, duration: 2 }}><Avatar user={chat.user} size="xl" className="!w-40 !h-40 shadow-2xl" /></motion.div>
              <div className="text-center"><h1 className="text-3xl font-bold mb-2 text-white">{chat.user.name}</h1><p className="text-[#27a7e7] font-medium tracking-wide uppercase text-sm">{callStatus === 'calling' ? t.calling : t.ringing}</p></div>
            </div>
            <div className="flex flex-col items-center gap-10 w-full max-sm px-10">
              <div className="flex items-center justify-between w-full">
                <CallControlButton active={callToggles.mute} onClick={() => setCallToggles(p => ({ ...p, mute: !p.mute }))} label={t.mute} icon={<svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M12,2A3,3 0 0,1 15,5V11A3,3 0 0,1 12,14A3,3 0 0,1 9,11V5A3,3 0 0,1 12,2M19,11C19,14.53 16.39,17.44 13,17.93V21H11V17.93C7.61,17.44 5,14.53 5,11H7A5,5 0 0,0 12,16A5,5 0 0,0 17,11H19Z" /></svg>} />
                <CallControlButton active={callToggles.video} onClick={() => setCallToggles(p => ({ ...p, video: !p.video }))} label={t.video} icon={<svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M17,10.5V7A1,1 0 0,0 16,6H4A1,1 0 0,0 3,7V17A1,1 0 0,0 4,18H16A1,1 0 0,0 17,17V13.5L21,17.5V6.5L17,10.5Z" /></svg>} />
                <CallControlButton active={callToggles.speaker} onClick={() => setCallToggles(p => ({ ...p, speaker: !p.speaker }))} label={t.speaker} icon={<svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M14,3.23V5.29C16.89,6.15 19,8.83 19,12C19,15.17 16.89,17.85 14,18.71V20.77C18.07,19.86 21,16.28 21,12C21,7.72 18.07,4.14 14,3.23M16.5,12C16.5,10.23 15.5,8.71 14,7.97V16.02C15.5,15.29 16.5,13.77 16.5,12M3,9V15H7L12,20V4L7,9H3Z" /></svg>} />
              </div>
              <button onClick={() => setIsCallOverlayOpen(false)} className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center text-white shadow-2xl hover:bg-red-600 active:scale-90 transition-all"><svg className="w-10 h-10 rotate-[135deg]" fill="currentColor" viewBox="0 0 24 24"><path d="M6.62,10.79C8.06,13.62 10.38,15.94 13.21,17.38L15.41,15.18C15.69,14.9 16.08,14.82 16.43,14.93C17.55,15.3 18.75,15.5 20,15.5A1,1 0 0,1 21,16.5V20A1,1 0 0,1 20,21A17,17 0 0,1 3,4A1,1 0 0,1 4,3H7.5A1,1 0 0,1 8.5,4C8.5,5.25 8.7,6.45 9.07,7.57C9.18,7.92 9.1,8.31 8.82,8.59L6.62,10.79Z" /></svg></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {contextMenu && (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="fixed z-[999] shadow-2xl rounded-xl py-2 min-w-[160px] border backdrop-blur-md" style={{ top: contextMenu.y, left: contextMenu.x, backgroundColor: colors.sidebar + 'e6', borderColor: colors.border }}>
            <button onClick={() => { setReplyingTo(contextMenu.msg); setContextMenu(null); }} className="w-full text-left px-4 py-2 hover:bg-black/5 flex items-center gap-3" style={{ color: colors.text }}><svg className="w-4 h-4 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" strokeWidth="2"/></svg>{t.reply}</button>
            {contextMenu.msg.isSelf && contextMenu.msg.text && !contextMenu.msg.isCall && <button onClick={() => { setEditingMsg(contextMenu.msg); setReplyingTo(null); setInputText(contextMenu.msg.text || ''); setContextMenu(null); }} className="w-full text-left px-4 py-2 hover:bg-black/5 flex items-center gap-3" style={{ color: colors.text }}><svg className="w-4 h-4 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth="2"/></svg>{t.edit}</button>}
            <button onClick={() => { onPinMessage(contextMenu.msg.id); setContextMenu(null); }} className="w-full text-left px-4 py-2 hover:bg-black/5 flex items-center gap-3" style={{ color: colors.text }}><svg className="w-4 h-4 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" strokeWidth="2"/></svg>{t.pin}</button>
            <button onClick={() => { onStartSelection(contextMenu.msg.id); setContextMenu(null); }} className="w-full text-left px-4 py-2 hover:bg-black/5 flex items-center gap-3" style={{ color: colors.text }}><svg className="w-4 h-4 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2"/></svg>{t.select}</button>
            <div className="h-[1px] my-1" style={{ backgroundColor: colors.border }} />
            <button onClick={() => { onDeleteMessage(contextMenu.msg.id); setContextMenu(null); }} className="w-full text-left px-4 py-2 hover:bg-red-500/10 flex items-center gap-3 text-red-500"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2"/></svg>{t.delete}</button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const CallControlButton: React.FC<{ active: boolean, onClick: () => void, label: string, icon: React.ReactNode }> = ({ active, onClick, label, icon }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-2 group">
    <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${active ? 'bg-white text-[#0e1621]' : 'bg-white/10 text-white hover:bg-white/20'}`}>{icon}</div>
    <span className="text-[11px] font-medium text-white/70 uppercase tracking-widest">{label}</span>
  </button>
);

export default ChatArea;