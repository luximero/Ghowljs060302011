import React from 'react';
import { User } from '../types';
import { TG_GRADIENTS } from '../constants';

interface AvatarProps {
  user: User;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showBadge?: boolean;
  borderColor?: string;
  onClick?: () => void;
  className?: string;
}

const Avatar: React.FC<AvatarProps> = ({ 
  user, 
  size = 'md', 
  showBadge = false, 
  borderColor = '#17212b',
  onClick,
  className = ""
}) => {
  const getInitials = (name: string) => {
    const parts = name.split(' ');
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  const getGradient = (id: string) => {
    const hash = id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return TG_GRADIENTS[hash % TG_GRADIENTS.length];
  };

  const dimensions = {
    sm: 'w-8 h-8 text-[12px]',
    md: 'w-11 h-11 text-[16px]',
    lg: 'w-14 h-14 text-[20px]',
    xl: 'w-16 h-16 text-[24px]'
  };

  const statusBadgeSize = {
    sm: 'w-2.5 h-2.5',
    md: 'w-3 h-3',
    lg: 'w-3.5 h-3.5',
    xl: 'w-4 h-4'
  };

  return (
    <div 
      className={`relative flex-shrink-0 cursor-pointer ${dimensions[size]} ${className}`}
      onClick={onClick}
    >
      {user.avatar ? (
        <img 
          src={user.avatar} 
          alt={user.name} 
          className="w-full h-full rounded-full object-cover shadow-sm"
        />
      ) : (
        <div 
          className="w-full h-full rounded-full flex items-center justify-center font-bold text-white shadow-inner"
          style={{ background: getGradient(user.id) }}
        >
          {getInitials(user.name)}
        </div>
      )}
      
      {showBadge && user.status === 'online' && (
        <div 
          className={`absolute bottom-0 right-0 ${statusBadgeSize[size]} bg-[#27a7e7] rounded-full border-2`}
          style={{ borderColor: borderColor }}
        />
      )}
    </div>
  );
};

export default Avatar;