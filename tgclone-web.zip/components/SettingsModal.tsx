import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '../types';
import { Language, translations } from '../translations';
import { THEMES } from '../constants';
import Avatar from './Avatar';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onUpdateUser: (updates: Partial<User>) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  theme: 'dark' | 'light';
  myPeerId?: string;
  onConnectToPartner?: (id: string) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, onClose, user, onUpdateUser, language, onLanguageChange, theme,
  myPeerId, onConnectToPartner
}) => {
  const t = translations[language];
  const colors = THEMES[theme];
  const [tempName, setTempName] = useState(user.name);
  const [partnerId, setPartnerId] = useState('');
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateUser({ name: tempName });
    onClose();
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        onUpdateUser({ avatar: ev.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = () => {
    if (myPeerId) {
      navigator.clipboard.writeText(myPeerId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleConnect = () => {
    if (onConnectToPartner && partnerId) {
      onConnectToPartner(partnerId);
      setPartnerId('');
      onClose();
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="relative w-full max-w-[440px] rounded-2xl shadow-2xl overflow-hidden"
          style={{ backgroundColor: colors.sidebar }}
        >
          <div className="p-6 flex items-center justify-between border-b" style={{ borderColor: colors.border }}>
            <h2 className="text-xl font-semibold" style={{ color: colors.text }}>{t.settings}</h2>
            <button onClick={onClose} className="ripple p-2 rounded-full text-[#708499] hover:bg-black/5">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div className="p-6 space-y-8 overflow-y-auto max-h-[70vh] custom-scrollbar">
            {/* Profile Section */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative group">
                <Avatar user={user} size="xl" onClick={() => fileInputRef.current?.click()} className="group-hover:opacity-90 transition-opacity" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="bg-black/40 rounded-full p-2">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  </div>
                </div>
                <input type="file" ref={fileInputRef} onChange={handleAvatarUpload} accept="image/*" className="hidden" />
              </div>
              <div className="w-full space-y-2">
                <label className="text-xs font-semibold text-[#27a7e7] uppercase">{t.name}</label>
                <input 
                  type="text" 
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="w-full bg-black/5 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-[#27a7e7] transition-all"
                  style={{ color: colors.text }}
                />
              </div>
            </div>

            {/* Connection Section */}
            <div className="space-y-4 pt-4 border-t" style={{ borderColor: colors.border }}>
              <h3 className="text-sm font-semibold text-[#27a7e7] uppercase">{t.devices}</h3>
              <div className="space-y-4">
                <div className="bg-black/5 p-4 rounded-xl space-y-2">
                  <label className="text-xs text-[#708499]">{t.myId}</label>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 font-mono text-sm truncate" style={{ color: colors.text }}>{myPeerId || t.connecting}</code>
                    <button 
                      onClick={copyToClipboard}
                      className="text-[#27a7e7] text-xs font-semibold uppercase hover:underline"
                    >
                      {copied ? t.copied : t.copy}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-[#708499] uppercase">{t.partnerId}</label>
                  <div className="flex gap-2">
                    <input 
                      type="text"
                      value={partnerId}
                      onChange={(e) => setPartnerId(e.target.value)}
                      placeholder="Paste ID here..."
                      className="flex-1 bg-black/5 rounded-lg px-4 py-2 outline-none text-sm"
                      style={{ color: colors.text }}
                    />
                    <button 
                      onClick={handleConnect}
                      className="bg-[#27a7e7] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-[#2b84d6] transition-colors"
                    >
                      {t.connect}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Language Section */}
            <div className="space-y-4 pt-4 border-t" style={{ borderColor: colors.border }}>
              <h3 className="text-sm font-semibold text-[#27a7e7] uppercase">{t.language}</h3>
              <div className="space-y-2">
                {(['en', 'ru'] as Language[]).map(lang => (
                  <button 
                    key={lang} 
                    onClick={() => onLanguageChange(lang)}
                    className="ripple w-full flex items-center justify-between p-3 rounded-xl transition-all hover:bg-black/5"
                  >
                    <span style={{ color: colors.text }}>{lang === 'en' ? 'English' : 'Русский'}</span>
                    {language === lang && (
                      <svg className="w-5 h-5 text-[#27a7e7]" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="p-6 bg-black/5 flex justify-end gap-3">
            <button onClick={onClose} className="ripple px-6 py-2 font-medium text-[#708499] hover:text-[#27a7e7]">{t.cancel}</button>
            <button onClick={handleSave} className="ripple px-6 py-2 bg-[#27a7e7] text-white rounded-lg font-medium hover:bg-[#2b84d6] shadow-lg">{t.save}</button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default SettingsModal;