
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { THEMES, EMOJIS, STICKERS } from '../constants';
import { Language } from '../translations';

interface EmojiPickerProps {
  onEmojiSelect: (emoji: string) => void;
  onStickerSelect: (url: string) => void;
  theme: 'dark' | 'light';
  language: Language;
}

const EmojiPicker: React.FC<EmojiPickerProps> = ({ onEmojiSelect, onStickerSelect, theme, language }) => {
  const [activeTab, setActiveTab] = useState<'emoji' | 'stickers' | 'gifs'>('emoji');
  const colors = THEMES[theme];

  return (
    <motion.div 
      initial={{ height: 0 }} 
      animate={{ height: 300 }} 
      exit={{ height: 0 }}
      className="w-full flex flex-col border-t overflow-hidden"
      style={{ backgroundColor: colors.sidebar, borderColor: colors.border }}
    >
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        {activeTab === 'emoji' && (
          <div className="grid grid-cols-8 md:grid-cols-10 gap-2">
            {EMOJIS.map((emoji, i) => (
              <button 
                key={i} 
                onClick={() => onEmojiSelect(emoji)}
                className="text-2xl hover:bg-black/10 p-1 rounded-lg transition-colors flex items-center justify-center"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}
        {activeTab === 'stickers' && (
          <div className="grid grid-cols-4 md:grid-cols-5 gap-4">
            {STICKERS.map((sticker, i) => (
              <motion.button 
                key={i} 
                whileHover={{ scale: 1.1 }}
                onClick={() => onStickerSelect(sticker)}
                className="aspect-square p-2 rounded-xl hover:bg-black/10 transition-colors overflow-hidden"
              >
                <img src={sticker} className="w-full h-full object-contain" alt="Sticker" />
              </motion.button>
            ))}
          </div>
        )}
        {activeTab === 'gifs' && (
          <div className="flex flex-col items-center justify-center h-full opacity-30 gap-2">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4" strokeWidth="2"/></svg>
            <p className="text-sm font-medium">{language === 'ru' ? 'GIF скоро появятся' : 'GIFs coming soon'}</p>
          </div>
        )}
      </div>

      {/* Footer Tabs */}
      <div className="flex h-12 border-t" style={{ borderColor: colors.border }}>
        <TabButton 
          active={activeTab === 'emoji'} 
          onClick={() => setActiveTab('emoji')} 
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2"/></svg>} 
        />
        <TabButton 
          active={activeTab === 'stickers'} 
          onClick={() => setActiveTab('stickers')} 
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" strokeWidth="2"/></svg>} 
        />
        <TabButton 
          active={activeTab === 'gifs'} 
          onClick={() => setActiveTab('gifs')} 
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h14a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth="2"/></svg>} 
        />
      </div>
    </motion.div>
  );
};

const TabButton: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode }> = ({ active, onClick, icon }) => (
  <button 
    onClick={onClick}
    className={`flex-1 flex items-center justify-center transition-colors ${active ? 'text-[#27a7e7] bg-black/5' : 'text-[#708499] hover:bg-black/5'}`}
  >
    {icon}
  </button>
);

export default EmojiPicker;
