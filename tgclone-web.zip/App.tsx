import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import SettingsModal from './components/SettingsModal';
import ProfileInfo from './components/ProfileInfo';
import ForwardModal from './components/ForwardModal';
import { Chat, Message, User } from './types';
import { INITIAL_CHATS, THEMES } from './constants';
import { getGeminiResponse } from './services/geminiService';
import { Language, translations } from './translations';
import { AnimatePresence } from 'framer-motion';

const LOCAL_STORAGE_KEY_MESSAGES = 'teleclone_messages_map_v4';
const LOCAL_STORAGE_KEY_CHATS = 'teleclone_chats_v4';
const LOCAL_STORAGE_KEY_THEME = 'teleclone_theme';
const LOCAL_STORAGE_KEY_USER = 'teleclone_self_user';
const LOCAL_STORAGE_KEY_LANG = 'teleclone_lang';
const LOCAL_STORAGE_KEY_PEER_ID = 'teleclone_my_peer_id';

declare var Peer: any;

const INCOMING_MSG_SOUND = 'https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3';

const App: React.FC = () => {
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_THEME);
    return (saved as 'dark' | 'light') || 'dark';
  });

  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_LANG);
    return (saved as Language) || 'en';
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_USER);
    if (saved) return JSON.parse(saved);
    return { id: 'me', name: 'User-' + Math.floor(Math.random() * 1000), avatar: '', status: 'online' };
  });

  const [chats, setChats] = useState<Chat[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_CHATS);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.map((c: any) => ({ ...c, lastActivity: new Date(c.lastActivity) }));
      } catch (e) {
        return INITIAL_CHATS;
      }
    }
    return INITIAL_CHATS;
  });

  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const activeChatIdRef = useRef<string | null>(null);

  useEffect(() => {
    activeChatIdRef.current = activeChatId;
  }, [activeChatId]);

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isForwardModalOpen, setIsForwardModalOpen] = useState(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<string[]>([]);
  
  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_MESSAGES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        Object.keys(parsed).forEach(chatId => {
          parsed[chatId] = parsed[chatId].map((m: any) => ({
            ...m,
            timestamp: new Date(m.timestamp)
          }));
        });
        return parsed;
      } catch (e) {
        return {};
      }
    }
    return {};
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [typingChatIds, setTypingChatIds] = useState<Set<string>>(new Set());

  const [myPeerId, setMyPeerId] = useState<string>('');
  const [peerInstance, setPeerInstance] = useState<any>(null);
  const [activeConnections, setActiveConnections] = useState<Record<string, any>>({});
  
  const incomingSoundRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => { localStorage.setItem(LOCAL_STORAGE_KEY_CHATS, JSON.stringify(chats)); }, [chats]);
  useEffect(() => { localStorage.setItem(LOCAL_STORAGE_KEY_MESSAGES, JSON.stringify(messagesMap)); }, [messagesMap]);
  useEffect(() => { localStorage.setItem(LOCAL_STORAGE_KEY_THEME, theme); }, [theme]);
  useEffect(() => { localStorage.setItem(LOCAL_STORAGE_KEY_USER, JSON.stringify(currentUser)); }, [currentUser]);
  useEffect(() => { localStorage.setItem(LOCAL_STORAGE_KEY_LANG, language); }, [language]);

  useEffect(() => {
    const savedPeerId = localStorage.getItem(LOCAL_STORAGE_KEY_PEER_ID);
    const peer = new Peer(savedPeerId || null, { debug: 1 });

    peer.on('open', (id: string) => {
      setMyPeerId(id);
      localStorage.setItem(LOCAL_STORAGE_KEY_PEER_ID, id);
    });

    peer.on('connection', (conn: any) => {
      handleIncomingConnection(conn);
    });

    setPeerInstance(peer);
    
    try {
      const audio = new Audio();
      audio.src = INCOMING_MSG_SOUND;
      audio.load();
      incomingSoundRef.current = audio;
    } catch (e) {
      console.warn("Failed to initialize notification sound", e);
    }

    const onFocus = () => { document.title = 'TeleClone Web'; };
    window.addEventListener('focus', onFocus);

    return () => {
      peer.destroy();
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  const handleIncomingConnection = (conn: any) => {
    conn.on('open', () => {
      const peerChatId = `peer-${conn.peer}`;
      setupConnectionListeners(conn, peerChatId);
      
      conn.send({
        type: 'handshake',
        name: currentUser.name,
        avatar: currentUser.avatar
      });

      setActiveConnections(prev => ({ ...prev, [peerChatId]: conn }));
    });
  };

  const setupConnectionListeners = (conn: any, chatId: string) => {
    conn.on('data', (data: any) => {
      if (data.type === 'handshake') {
        setChats(prev => {
          const exists = prev.find(c => c.id === chatId);
          if (exists) {
            return prev.map(c => c.id === chatId ? { 
              ...c, 
              user: { ...c.user, name: data.name, avatar: data.avatar, status: 'online' as const } 
            } : c);
          }
          const newUser: User = { 
            id: chatId, 
            name: data.name, 
            avatar: data.avatar, 
            status: 'online' 
          };
          return [{ id: chatId, user: newUser, lastActivity: new Date(), unreadCount: 0 }, ...prev];
        });
        return;
      }

      if (data.type === 'text' || data.type === 'voice' || data.type === 'media') {
        const voiceUrlFinal = (data.type === 'voice' && data.mediaData) ? data.mediaData : data.voiceUrl;

        const receivedMsg: Message = {
          id: `p2p-${Date.now()}`,
          senderId: chatId,
          text: data.text,
          image: data.image,
          isVoice: data.type === 'voice',
          voiceUrl: voiceUrlFinal,
          voiceDuration: data.voiceDuration,
          timestamp: new Date(data.time || Date.now()),
          status: 'read',
          isSelf: false
        };
        
        setMessagesMap(prev => ({
          ...prev,
          [chatId]: [...(prev[chatId] || []), receivedMsg]
        }));

        setChats(prev => prev.map(chat => {
          if (chat.id === chatId) {
            const isNotFocused = activeChatIdRef.current !== chatId;
            
            if (isNotFocused) {
              if (incomingSoundRef.current && incomingSoundRef.current.src) {
                incomingSoundRef.current.play().catch(e => console.warn("Audio play blocked", e));
              }
              if (document.hidden) document.title = 'New Message!';
            }

            const lastMsgText = data.type === 'voice' ? 'Voice message' : (data.image ? 'Photo' : data.text);

            return { 
              ...chat, 
              lastMessage: lastMsgText, 
              lastMessageTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
              lastActivity: new Date(),
              unreadCount: isNotFocused ? (chat.unreadCount || 0) + 1 : 0 
            };
          }
          return chat;
        }));
      }
    });

    conn.on('close', () => {
      setChats(prev => prev.map(c => c.id === chatId ? { ...c, user: { ...c.user, status: 'offline' as const } } : c));
      setActiveConnections(prev => {
        const next = { ...prev };
        delete next[chatId];
        return next;
      });
    });
  };

  const handleConnectToPartner = (targetId: string) => {
    if (!peerInstance || !targetId) return;
    const conn = peerInstance.connect(targetId);
    handleIncomingConnection(conn);
  };

  const activeChat = useMemo(() => chats.find(c => c.id === activeChatId) || null, [chats, activeChatId]);
  
  const filteredChats = useMemo(() => {
    const q = searchQuery.toLowerCase();
    return chats
      .filter(chat => 
        chat.user.name.toLowerCase().includes(q) ||
        chat.lastMessage?.toLowerCase().includes(q)
      )
      .sort((a, b) => b.lastActivity.getTime() - a.lastActivity.getTime());
  }, [chats, searchQuery]);

  const currentThemeColors = THEMES[theme];

  const updateMessageStatus = (chatId: string, messageId: string, status: 'sent' | 'read') => {
    setMessagesMap(prev => {
      const msgs = prev[chatId] || [];
      return { ...prev, [chatId]: msgs.map(m => m.id === messageId ? { ...m, status } : m) };
    });
  };

  const handleSendMessage = useCallback(async (
    text?: string, 
    replyToId?: string, 
    editId?: string, 
    image?: string, 
    isVoice?: boolean, 
    voiceDuration?: number, 
    forwardedFrom?: string,
    isSticker?: boolean,
    isCall?: boolean,
    voiceUrl?: string,
    mediaData?: string 
  ) => {
    const currentId = activeChatIdRef.current;
    if (!currentId) return;
    
    if (editId) {
      setMessagesMap(prev => ({
        ...prev,
        [currentId]: (prev[currentId] || []).map(m => m.id === editId ? { ...m, text, isEdited: true } : m)
      }));
      return;
    }

    const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // CRITICAL: Use mediaData (base64) as voiceUrl for persistence if provided.
    const finalVoiceUrl = mediaData || voiceUrl;
    
    const newMessage: Message = { id: messageId, senderId: currentUser.id, text, image, isVoice, voiceDuration, voiceUrl: finalVoiceUrl, timestamp: now, status: 'sending', isSelf: true, replyToId, forwardedFrom, isSticker, isCall };
    
    setMessagesMap(prev => ({ ...prev, [currentId]: [...(prev[currentId] || []), newMessage] }));
    
    const displayMsg = isCall ? 'Call' : isSticker ? 'Sticker' : isVoice ? 'Voice message' : image ? 'Photo' : text || '';
    setChats(prev => prev.map(chat => 
      chat.id === currentId ? { 
        ...chat, 
        lastMessage: displayMsg, 
        lastMessageTime: formattedTime, 
        lastActivity: now,
        unreadCount: 0 
      } : chat
    ));

    const conn = activeConnections[currentId];
    if (conn) {
      const payload: any = {
        type: isVoice ? 'voice' : (image ? 'media' : 'text'),
        text: text,
        image: image,
        voiceDuration: voiceDuration,
        mediaData: mediaData,
        time: now.toISOString(),
        sender: currentUser.name
      };
      conn.send(payload);
      setTimeout(() => updateMessageStatus(currentId, messageId, 'sent'), 200);
      setTimeout(() => updateMessageStatus(currentId, messageId, 'read'), 600);
    } else {
      setTimeout(() => {
        updateMessageStatus(currentId, messageId, 'sent');
        setTimeout(() => updateMessageStatus(currentId, messageId, 'read'), 1000);
      }, 500);

      if (currentId === '1' && text && !forwardedFrom && !isCall) {
        setTypingChatIds(prev => new Set(prev).add('1'));
        const aiResponse = await getGeminiResponse(text);
        const aiTime = new Date();
        const aiFormattedTime = aiTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const aiMessageId = `ai-${Date.now()}`;
        
        const aiMessage: Message = { id: aiMessageId, senderId: '1', text: aiResponse, timestamp: aiTime, status: 'read', isSelf: false };
        setTypingChatIds(prev => { const next = new Set(prev); next.delete('1'); return next; });
        setMessagesMap(prev => ({ ...prev, ['1']: [...(prev['1'] || []), aiMessage] }));
        setChats(prev => prev.map(chat => {
          if (chat.id === '1') {
            const isNotFocused = activeChatIdRef.current !== '1';
            return { ...chat, lastMessage: aiResponse, lastMessageTime: aiFormattedTime, lastActivity: aiTime, unreadCount: isNotFocused ? (chat.unreadCount || 0) + 1 : 0 };
          }
          return chat;
        }));
      }
    }
  }, [currentUser, activeConnections]);

  const handleDeleteMessage = useCallback((messageId: string) => {
    const currentId = activeChatIdRef.current;
    if (!currentId) return;
    setMessagesMap(prev => ({ ...prev, [currentId]: (prev[currentId] || []).filter(m => m.id !== messageId) }));
  }, []);

  const handlePinMessage = useCallback((messageId: string) => {
    const currentId = activeChatIdRef.current;
    if (!currentId) return;
    setChats(prev => prev.map(chat => 
      chat.id === currentId ? { ...chat, pinnedMessageId: messageId } : chat
    ));
  }, []);

  const handleUnpinMessage = useCallback(() => {
    const currentId = activeChatIdRef.current;
    if (!currentId) return;
    setChats(prev => prev.map(chat => 
      chat.id === currentId ? { ...chat, pinnedMessageId: undefined } : chat
    ));
  }, []);

  const handleForwardMessages = useCallback((targetChatId: string) => {
    const sourceChatId = activeChatIdRef.current;
    if (!sourceChatId || selectedMessageIds.length === 0) return;
    
    const messagesToForward = (messagesMap[sourceChatId] || []).filter(m => selectedMessageIds.includes(m.id));
    const sourceChat = chats.find(c => c.id === sourceChatId);
    const senderName = sourceChat?.user.name || "Unknown";

    setActiveChatId(targetChatId);
    
    messagesToForward.forEach((msg, index) => {
      setTimeout(() => {
        const messageId = `fwd-${Date.now()}-${index}`;
        const now = new Date();
        const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        const newMessage: Message = { 
          ...msg, 
          id: messageId, 
          senderId: currentUser.id, 
          timestamp: now, 
          status: 'read', 
          isSelf: true,
          forwardedFrom: senderName 
        };

        setMessagesMap(prev => ({ ...prev, [targetChatId]: [...(prev[targetChatId] || []), newMessage] }));
        
        const conn = activeConnections[targetChatId];
        if (conn) {
          conn.send({
            type: msg.isVoice ? 'voice' : (msg.image ? 'media' : 'text'),
            text: msg.text,
            image: msg.image,
            voiceDuration: msg.voiceDuration,
            time: now.toISOString(),
            sender: currentUser.name
          });
        }

        setChats(prev => prev.map(chat => 
          chat.id === targetChatId ? { 
            ...chat, 
            lastMessage: msg.text || (msg.isVoice ? 'Voice' : 'Photo'), 
            lastMessageTime: formattedTime, 
            lastActivity: now,
            unreadCount: 0 
          } : chat
        ));
      }, index * 50);
    });

    setSelectedMessageIds([]);
    setIsForwardModalOpen(false);
  }, [selectedMessageIds, messagesMap, chats, currentUser, activeConnections]);

  const handleChatSelect = (chat: Chat) => {
    setActiveChatId(chat.id);
    setIsProfileOpen(false);
    setSelectedMessageIds([]);
    setChats(prev => prev.map(c => c.id === chat.id ? { ...c, unreadCount: 0 } : c));
  };

  const toggleMessageSelection = (id: string) => {
    setSelectedMessageIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  return (
    <div className={`flex h-screen w-screen overflow-hidden antialiased transition-colors duration-300 ${theme === 'dark' ? 'dark' : ''}`} style={{ backgroundColor: currentThemeColors.bg, color: currentThemeColors.text }}>
      <Sidebar 
        currentUser={currentUser}
        onUpdateCurrentUser={(upd) => setCurrentUser(p => ({...p, ...upd}))}
        chats={filteredChats} 
        activeChatId={activeChatId} 
        onChatSelect={handleChatSelect}
        isMobileChatOpen={!!activeChatId}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        typingChatIds={typingChatIds}
        theme={theme}
        onToggleTheme={() => setTheme(prev => prev === 'dark' ? 'light' : 'dark')}
        onOpenSavedMessages={() => {
          const saved = chats.find(c => c.id === 'saved');
          if (saved) handleChatSelect(saved);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        language={language}
      />
      <ChatArea 
        chat={activeChat} 
        messages={activeChatId ? (messagesMap[activeChatId] || []) : []} 
        onSendMessage={handleSendMessage} 
        onDeleteMessage={handleDeleteMessage} 
        onPinMessage={handlePinMessage}
        onUnpinMessage={handleUnpinMessage}
        onBack={() => setActiveChatId(null)} 
        onHeaderClick={() => setIsProfileOpen(prev => !prev)}
        isTyping={activeChatId ? typingChatIds.has(activeChatId) : false} 
        theme={theme} 
        language={language} 
        selectedMessageIds={selectedMessageIds}
        onSelectMessage={toggleMessageSelection}
        onClearSelection={() => setSelectedMessageIds([])}
        onDeleteSelected={() => {
           const currentId = activeChatIdRef.current;
           if (!currentId) return;
           setMessagesMap(prev => ({ ...prev, [currentId]: (prev[currentId] || []).filter(m => !selectedMessageIds.includes(m.id)) }));
           setSelectedMessageIds([]);
        }}
        onForwardSelected={() => setIsForwardModalOpen(true)}
        onStartSelection={(msgId) => setSelectedMessageIds([msgId])}
      />
      
      <AnimatePresence>
        {isProfileOpen && activeChat && (
          <ProfileInfo 
            user={activeChat.user} 
            theme={theme} 
            language={language} 
            onClose={() => setIsProfileOpen(false)} 
          />
        )}
      </AnimatePresence>

      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        user={currentUser} 
        onUpdateUser={(upd) => setCurrentUser(p => ({...p, ...upd}))} 
        language={language} 
        onLanguageChange={setLanguage} 
        theme={theme}
        myPeerId={myPeerId}
        onConnectToPartner={handleConnectToPartner}
      />

      {isForwardModalOpen && (
        <ForwardModal 
          isOpen={isForwardModalOpen}
          onClose={() => setIsForwardModalOpen(false)}
          chats={chats}
          onForward={handleForwardMessages}
          theme={theme}
          language={language}
        />
      )}
    </div>
  );
};

export default App;